
import React from "react";
import { FaLinkedin, FaGithub } from "react-icons/fa";
import "./App.css";

function App() {
  return (
    <div className="App">
      <h1>Hello, I'm Saurabh 👋</h1>
      <a href="/saurabh.pdf" download target="_blank" rel="noopener noreferrer">
        <button className="btn-resume">Download Resume</button>
      </a>
      <div className="socials">
        <a href="https://www.linkedin.com/in/saur12/" target="_blank" rel="noopener noreferrer">
          <FaLinkedin size={30} />
        </a>
        <a href="https://github.com/saurabhchaudhary05" target="_blank" rel="noopener noreferrer">
          <FaGithub size={30} />
        </a>
      </div>
    </div>
  );
}

export default App;
